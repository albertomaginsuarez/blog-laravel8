<?php $__env->startSection("content"); ?>
    <div class="flex justify-center flex-wrap p-4 mt-5">
        <?php echo $__env->make("projects.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/israel/cursosdesarrolloweb/laravel8/blog-laravel8/resources/views/projects/create.blade.php ENDPATH**/ ?>